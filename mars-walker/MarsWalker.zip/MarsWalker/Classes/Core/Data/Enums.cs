﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MarsRover.Classes.Core.Data
{
    public enum Axis { X, Y, Z };
    public enum PositionType { Absolute, Relative }
}
